import os
import torch
import numpy as np
import cv2



class UWIQA(torch.utils.data.Dataset):
    def __init__(self, dis_path, txt_file_name, transform, keep_ratio):
        super(UWIQA, self).__init__()
        self.dis_path = dis_path
        self.txt_file_name = txt_file_name
        self.transform = transform
        self.keep_ratio = keep_ratio

        dis_files_data, score_data = [], []
        with open(self.txt_file_name, 'r') as listFile:
            for line in listFile:
                dis, score = line.split()
                dis = dis[:-1]
                score = float(score)
                dis_files_data.append(dis)
                score_data.append(score)

        # reshape score_list (1xn -> nx1)
        score_data = np.array(score_data)
#        score_data = self.normalization(score_data)
        score_data = score_data.astype('float').reshape(-1, 1)

        self.data_dict = {'d_img_list': dis_files_data, 'score_list': score_data}



    def __len__(self):
        return int(len(self.data_dict['d_img_list'])*self.keep_ratio)


    def __getitem__(self, idx):
        d_img_name = self.data_dict['d_img_list'][idx]
        d_img = cv2.imread(os.path.join(self.dis_path,d_img_name), cv2.IMREAD_COLOR)
        d_img = cv2.cvtColor(d_img, cv2.COLOR_BGR2RGB)
        d_img = np.array(d_img).astype('float32') / 255
        d_img = cv2.resize(d_img, (224, 224))
        d_img = np.transpose(d_img, (2, 0, 1))

        score = self.data_dict['score_list'][idx]
        sample = {
            'd_img_org': d_img,
            'score': score,
            'd_name': d_img_name
        }
        if self.transform:
            sample = self.transform(sample)
        return sample

